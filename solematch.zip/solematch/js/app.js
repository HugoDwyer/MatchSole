// SoleMatch — quiz flow, rendering, and state
// Depends on SHOES (shoes.js) and getMatches (matchLogic.js)

const app = document.getElementById("app");

const state = {
  screen: "landing", // "landing" | "quiz" | "results"
  step: "discipline",
  history: [],
  units: { weight: "kg", distance: "km" },
  answers: {
    discipline: null,
    spikeChoice: null,
    eventType: null,
    age: 16,
    weightKg: 60,
    weeklyDistanceKm: 30,
    pronation: null,
    cushioningPref: null,
    budgetMax: 150,
    width: null
  }
};

// ---------- Step flow ----------

function getNextStep(current, answers) {
  switch (current) {
    case "discipline":
      return answers.discipline === "track" || answers.discipline === "xc"
        ? "spikeChoice"
        : "stats";
    case "spikeChoice":
      return answers.spikeChoice === "spikes" ? "eventType" : "stats";
    case "eventType":
      return "stats";
    case "stats":
      return "distance";
    case "distance":
      return "pronation";
    case "pronation":
      return "cushioning";
    case "cushioning":
      return "budget";
    case "budget":
      return "width";
    case "width":
      return "results";
    default:
      return "results";
  }
}

function estimateTotalSteps(answers) {
  let total = 7; // discipline, stats, distance, pronation, cushioning, budget, width
  if (answers.discipline === "track" || answers.discipline === "xc") total += 1;
  if (answers.spikeChoice === "spikes") total += 1;
  return total;
}

function stepIndexInFlow(stepId, answers) {
  const order = ["discipline"];
  if (answers.discipline === "track" || answers.discipline === "xc") order.push("spikeChoice");
  if (answers.spikeChoice === "spikes") order.push("eventType");
  order.push("stats", "distance", "pronation", "cushioning", "budget", "width");
  const idx = order.indexOf(stepId);
  return idx === -1 ? order.length : idx;
}

function goNext() {
  const next = getNextStep(state.step, state.answers);
  state.history.push(state.step);
  if (next === "results") {
    state.screen = "results";
  }
  state.step = next;
  render();
}

function goBack() {
  if (state.history.length === 0) {
    state.screen = "landing";
    render();
    return;
  }
  state.step = state.history.pop();
  render();
}

function restart() {
  state.screen = "landing";
  state.step = "discipline";
  state.history = [];
  state.answers = {
    discipline: null,
    spikeChoice: null,
    eventType: null,
    age: 16,
    weightKg: 60,
    weeklyDistanceKm: 30,
    pronation: null,
    cushioningPref: null,
    budgetMax: 150,
    width: null
  };
  render();
}

// ---------- Unit conversion helpers ----------

const kgToLb = (kg) => Math.round(kg * 2.20462);
const lbToKg = (lb) => Math.round(lb / 2.20462);
const kmToMi = (km) => Math.round(km * 0.621371);
const miToKm = (mi) => Math.round(mi / 0.621371);

// ---------- Rendering ----------

function render() {
  app.innerHTML = "";
  if (state.screen === "landing") {
    app.appendChild(renderLanding());
  } else if (state.screen === "quiz") {
    app.appendChild(renderQuizShell());
  } else if (state.screen === "results") {
    app.appendChild(renderResults());
  }
}

function el(tag, className, html) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

function renderLanding() {
  const screen = el("div", "screen landing");
  screen.innerHTML = `
    <div class="container">
      <svg class="track-line" viewBox="0 0 420 64" xmlns="http://www.w3.org/2000/svg">
        <path d="M10,50 C90,10 150,58 210,32 C270,6 330,54 410,20" />
      </svg>
      <h1 class="wordmark">SOLE<span class="accent">MATCH</span></h1>
      <p class="landing-sub">A few quick questions about how you run — road, track, trail, or cross country — and we'll match you to the shoe built for it.</p>
      <button class="btn-primary" id="start-btn">Start the quiz →</button>
    </div>
  `;
  screen.querySelector("#start-btn").addEventListener("click", () => {
    state.screen = "quiz";
    render();
  });
  return screen;
}

function renderQuizShell() {
  const screen = el("div", "screen");
  const wrap = el("div", "container");

  const totalSteps = estimateTotalSteps(state.answers);
  const currentIndex = stepIndexInFlow(state.step, state.answers);
  const pct = Math.min(100, Math.round(((currentIndex) / totalSteps) * 100));

  const header = el("div", "quiz-header");
  header.innerHTML = `
    <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
    <div class="step-count">Step ${currentIndex + 1} of ${totalSteps}</div>
  `;
  wrap.appendChild(header);
  wrap.appendChild(renderStepBody(state.step));
  screen.appendChild(wrap);
  return screen;
}

function renderStepBody(step) {
  const body = el("div");
  const stepRenderers = {
    discipline: renderDiscipline,
    spikeChoice: renderSpikeChoice,
    eventType: renderEventType,
    stats: renderStats,
    distance: renderDistance,
    pronation: renderPronation,
    cushioning: renderCushioning,
    budget: renderBudget,
    width: renderWidth
  };
  (stepRenderers[step] || renderDiscipline)(body);
  return body;
}

function addNavRow(container, { canGoNext }) {
  const nav = el("div", "nav-row");
  const back = el("button", "btn-back", "← Back");
  back.addEventListener("click", goBack);

  const next = el("button", "btn-next", "Continue");
  next.disabled = !canGoNext();
  next.addEventListener("click", goNext);

  nav.appendChild(back);
  nav.appendChild(next);
  container.appendChild(nav);
  return next;
}

function choiceGrid(container, options, currentValue, onSelect, singleCol = false) {
  const grid = el("div", `choice-grid${singleCol ? " single-col" : ""}`);
  options.forEach((opt) => {
    const btn = el("button", "choice-btn" + (currentValue === opt.value ? " selected" : ""));
    btn.innerHTML = `<span class="choice-label">${opt.label}</span>${opt.hint ? `<span class="choice-hint">${opt.hint}</span>` : ""}`;
    btn.addEventListener("click", () => {
      onSelect(opt.value);
      render();
    });
    grid.appendChild(btn);
  });
  container.appendChild(grid);
}

// ---- Step 1: Discipline ----
function renderDiscipline(body) {
  body.appendChild(el("div", "question", "What type of running are you shoe shopping for?"));
  body.appendChild(el("div", "question-sub", "This decides the whole shape of your match."));
  choiceGrid(body, [
    { value: "road", label: "Road", hint: "Pavement, footpaths, road races" },
    { value: "track", label: "Track", hint: "Sprints or distance on the oval" },
    { value: "trail", label: "Trail", hint: "Dirt, technical, off-road" },
    { value: "xc", label: "Cross country", hint: "Grass, mud, spikes or trainers" }
  ], state.answers.discipline, (v) => { state.answers.discipline = v; });
  addNavRow(body, { canGoNext: () => !!state.answers.discipline });
}

// ---- Step 1b: Spikes or trainers ----
function renderSpikeChoice(body) {
  body.appendChild(el("div", "question", "Spikes or regular trainers?"));
  body.appendChild(el("div", "question-sub", "Spikes for race day grip, trainers for training and easy days."));
  choiceGrid(body, [
    { value: "spikes", label: "Spikes", hint: "Racing on the track or XC course" },
    { value: "trainers", label: "Trainers", hint: "Training runs, warm-ups, easy days" }
  ], state.answers.spikeChoice, (v) => { state.answers.spikeChoice = v; });
  addNavRow(body, { canGoNext: () => !!state.answers.spikeChoice });
}

// ---- Step 1c: Event type ----
function renderEventType(body) {
  body.appendChild(el("div", "question", "What event are you racing?"));
  body.appendChild(el("div", "question-sub", "Sprint spikes and distance spikes are built very differently."));
  choiceGrid(body, [
    { value: "sprint", label: "Sprints", hint: "100m–400m, hurdles" },
    { value: "middle", label: "Middle distance", hint: "800m–1500m" },
    { value: "long", label: "Long distance", hint: "3000m and up, XC" },
    { value: "unsure", label: "Not sure yet", hint: "Let SoleMatch decide" }
  ], state.answers.eventType, (v) => { state.answers.eventType = v; });
  addNavRow(body, { canGoNext: () => !!state.answers.eventType });
}

// ---- Step 2: Age + Weight sliders ----
function renderStats(body) {
  body.appendChild(el("div", "question", "A bit about you"));
  body.appendChild(el("div", "question-sub", "Age and weight both change how much support and cushioning you'll want."));

  // Age slider
  const ageBlock = el("div", "slider-block");
  ageBlock.innerHTML = `
    <div class="slider-top">
      <span class="slider-label">Age</span>
      <span class="slider-value" id="age-value">${state.answers.age}</span>
    </div>
    <input type="range" id="age-slider" min="10" max="80" step="1" value="${state.answers.age}">
  `;
  body.appendChild(ageBlock);
  ageBlock.querySelector("#age-slider").addEventListener("input", (e) => {
    state.answers.age = Number(e.target.value);
    ageBlock.querySelector("#age-value").textContent = state.answers.age;
    updateNextButton(body);
  });

  // Weight slider with kg/lb toggle
  const isLb = state.units.weight === "lb";
  const weightMin = isLb ? kgToLb(25) : 25;
  const weightMax = isLb ? kgToLb(150) : 150;
  const weightVal = isLb ? kgToLb(state.answers.weightKg) : state.answers.weightKg;

  const weightBlock = el("div", "slider-block");
  weightBlock.innerHTML = `
    <div class="slider-top">
      <span class="slider-label">Weight
        <span class="unit-toggle">
          <button data-unit="kg" class="${!isLb ? "active" : ""}">kg</button>
          <button data-unit="lb" class="${isLb ? "active" : ""}">lb</button>
        </span>
      </span>
      <span class="slider-value" id="weight-value">${weightVal} ${state.units.weight}</span>
    </div>
    <input type="range" id="weight-slider" min="${weightMin}" max="${weightMax}" step="1" value="${weightVal}">
  `;
  body.appendChild(weightBlock);

  weightBlock.querySelector("#weight-slider").addEventListener("input", (e) => {
    const raw = Number(e.target.value);
    state.answers.weightKg = state.units.weight === "lb" ? lbToKg(raw) : raw;
    weightBlock.querySelector("#weight-value").textContent = `${raw} ${state.units.weight}`;
  });

  weightBlock.querySelectorAll(".unit-toggle button").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.units.weight = btn.dataset.unit;
      render();
    });
  });

  addNavRow(body, { canGoNext: () => true });
}

// ---- Step 3: Weekly distance ----
function renderDistance(body) {
  body.appendChild(el("div", "question", "How far do you run in a typical week?"));
  body.appendChild(el("div", "question-sub", "Higher weekly volume usually means you'll want more cushioning underfoot."));

  const isMi = state.units.distance === "mi";
  const distMax = isMi ? kmToMi(150) : 150;
  const distVal = isMi ? kmToMi(state.answers.weeklyDistanceKm) : state.answers.weeklyDistanceKm;

  const block = el("div", "slider-block");
  block.innerHTML = `
    <div class="slider-top">
      <span class="slider-label">Weekly distance
        <span class="unit-toggle">
          <button data-unit="km" class="${!isMi ? "active" : ""}">km</button>
          <button data-unit="mi" class="${isMi ? "active" : ""}">mi</button>
        </span>
      </span>
      <span class="slider-value" id="distance-value">${distVal}${distVal >= distMax ? "+" : ""} ${state.units.distance}</span>
    </div>
    <input type="range" id="distance-slider" min="0" max="${distMax}" step="5" value="${distVal}">
  `;
  body.appendChild(block);

  block.querySelector("#distance-slider").addEventListener("input", (e) => {
    const raw = Number(e.target.value);
    state.answers.weeklyDistanceKm = state.units.distance === "mi" ? miToKm(raw) : raw;
    const suffix = raw >= distMax ? "+" : "";
    block.querySelector("#distance-value").textContent = `${raw}${suffix} ${state.units.distance}`;
  });

  block.querySelectorAll(".unit-toggle button").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.units.distance = btn.dataset.unit;
      render();
    });
  });

  addNavRow(body, { canGoNext: () => true });
}

// ---- Step 4: Pronation ----
function renderPronation(body) {
  body.appendChild(el("div", "question", "Which edge of your old shoes wears down more?"));
  body.appendChild(el("div", "question-sub", "This tells us how your foot rolls as it strikes the ground."));
  choiceGrid(body, [
    { value: "overpronation", label: "Inside edge", hint: "Overpronation" },
    { value: "supination", label: "Outside edge", hint: "Supination" },
    { value: "neutral", label: "Even wear", hint: "Neutral" },
    { value: "unsure", label: "Not sure", hint: "" },
    { value: "noshoes", label: "I don't have old shoes to check", hint: "" }
  ], state.answers.pronation, (v) => { state.answers.pronation = v; }, true);
  addNavRow(body, { canGoNext: () => !!state.answers.pronation });
}

// ---- Step 5: Cushioning ----
function renderCushioning(body) {
  body.appendChild(el("div", "question", "What do you want the shoe to feel like?"));
  choiceGrid(body, [
    { value: "max", label: "Max cushioning", hint: "Soft and comfortable" },
    { value: "balanced", label: "Balanced", hint: "A bit of both" },
    { value: "firm", label: "Firm & responsive", hint: "More pop, less pillow" },
    { value: "minimal", label: "Barely-there", hint: "Maximum ground feel" }
  ], state.answers.cushioningPref, (v) => { state.answers.cushioningPref = v; });
  addNavRow(body, { canGoNext: () => !!state.answers.cushioningPref });
}

// ---- Step 6: Budget ----
function renderBudget(body) {
  body.appendChild(el("div", "question", "What's your budget?"));
  body.appendChild(el("div", "question-sub", "Drag all the way right for no ceiling — race-day carbon shoes can run well past $300."));

  const block = el("div", "slider-block");
  const val = state.answers.budgetMax;
  const display = val >= 500 ? "$500+" : `$${val}`;
  block.innerHTML = `
    <div class="slider-top">
      <span class="slider-label">Budget</span>
      <span class="slider-value" id="budget-value">${display}</span>
    </div>
    <input type="range" id="budget-slider" min="50" max="500" step="10" value="${val}">
  `;
  body.appendChild(block);

  block.querySelector("#budget-slider").addEventListener("input", (e) => {
    const raw = Number(e.target.value);
    state.answers.budgetMax = raw;
    block.querySelector("#budget-value").textContent = raw >= 500 ? "$500+" : `$${raw}`;
  });

  addNavRow(body, { canGoNext: () => true });
}

// ---- Step 7: Width ----
function renderWidth(body) {
  body.appendChild(el("div", "question", "Do you need a wider shoe?"));
  choiceGrid(body, [
    { value: "narrow", label: "Narrow", hint: "" },
    { value: "standard", label: "Standard", hint: "" },
    { value: "wide", label: "Wide", hint: "" },
    { value: "extra-wide", label: "Extra wide", hint: "" }
  ], state.answers.width, (v) => { state.answers.width = v; });
  addNavRow(body, { canGoNext: () => !!state.answers.width });
}

function updateNextButton(body) {
  const btn = body.querySelector(".btn-next");
  if (btn) btn.disabled = false;
}

// ---------- Results ----------

function renderResults() {
  const screen = el("div", "screen");
  const wrap = el("div", "container");

  const matches = getMatches(state.answers, 3);
  const [top, ...alts] = matches;

  const heading = el("div", "results-heading");
  heading.innerHTML = `
    <div class="eyebrow">Your match</div>
    <h2>Here's your shoe</h2>
  `;
  wrap.appendChild(heading);

  if (!top) {
    wrap.appendChild(el("p", null, "We couldn't find a confident match — try adjusting your answers."));
  } else {
    const topCard = el("div", "top-match");
    topCard.innerHTML = `
      <img src="${top.image}" alt="${top.brand} ${top.model}">
      <div>
        <div class="shoe-brand">${top.brand}</div>
        <div class="shoe-name">${top.model}</div>
        <div class="shoe-price">$${top.price}</div>
        <p class="shoe-blurb">${top.blurb}</p>
      </div>
    `;
    wrap.appendChild(topCard);

    if (alts.length) {
      const altGrid = el("div", "alt-matches");
      alts.forEach((shoe) => {
        const card = el("div", "alt-card");
        card.innerHTML = `
          <img src="${shoe.image}" alt="${shoe.brand} ${shoe.model}">
          <div class="shoe-brand">${shoe.brand}</div>
          <div class="shoe-name">${shoe.model}</div>
          <div class="shoe-price">$${shoe.price}</div>
        `;
        altGrid.appendChild(card);
      });
      wrap.appendChild(altGrid);
    }
  }

  const retakeRow = el("div", "retake-row");
  const retakeBtn = el("button", "btn-retake", "Retake the quiz");
  retakeBtn.addEventListener("click", restart);
  retakeRow.appendChild(retakeBtn);
  wrap.appendChild(retakeRow);

  screen.appendChild(wrap);
  return screen;
}

// ---------- Init ----------
render();
