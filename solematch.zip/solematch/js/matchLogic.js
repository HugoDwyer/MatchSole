// SoleMatch scoring engine
// Takes the runner's quiz answers and scores every shoe in SHOES,
// returning the top 3 matches.

/**
 * Roughly buckets the runner's experience level from age + weekly volume.
 * Used mainly to decide between waffle/flat spikes (newer runners)
 * and proper distance/sprint spikes (more experienced runners).
 */
function deriveExperience(answers) {
  const { age, weeklyDistanceKm } = answers;
  if (age <= 14) return "beginner";
  if (age <= 17 && weeklyDistanceKm < 30) return "beginner";
  if (weeklyDistanceKm >= 50 || age >= 18) return "advanced";
  return "intermediate";
}

/**
 * Figures out which shoe categories are even in play, based on discipline
 * and (if track/XC) the spikes-vs-trainers follow-up.
 */
function getCandidateCategories(answers) {
  const experience = deriveExperience(answers);

  if (answers.discipline === "road") return ["road", "road-racer"];
  if (answers.discipline === "trail") return ["trail"];

  // track or cross country
  if (answers.spikeChoice === "trainers") return ["road"];

  // spikeChoice === "spikes"
  if (answers.eventType === "sprint") {
    return experience === "beginner" ? ["spike-waffle"] : ["spike-sprint"];
  }
  // middle / long / unsure
  return experience === "beginner" ? ["spike-waffle"] : ["spike-distance"];
}

function cushioningTarget(pref) {
  return { max: 5, balanced: 3, firm: 2, minimal: 1 }[pref] ?? 3;
}

function responsivenessTarget(pref) {
  return { max: 2, balanced: 3, firm: 4, minimal: 5 }[pref] ?? 3;
}

function scoreShoe(shoe, answers) {
  let score = 0;
  const experience = deriveExperience(answers);

  // Cushioning feel match (heaviest weight — this is the core "feel" question)
  score -= Math.abs(shoe.cushioning - cushioningTarget(answers.cushioningPref)) * 3;
  score -= Math.abs(shoe.responsiveness - responsivenessTarget(answers.cushioningPref)) * 2;

  // Pronation / support match
  if (answers.pronation === "overpronation") {
    score += shoe.pronationSupport === "stability" ? 6 : -2;
  } else if (answers.pronation === "supination" || answers.pronation === "neutral") {
    score += shoe.pronationSupport === "neutral" ? 4 : -3;
  }
  // "unsure" / "no old shoes" — no penalty either way

  // Weight suitability
  if (answers.weightKg >= shoe.minWeightKg && answers.weightKg <= shoe.maxWeightKg) {
    score += 5;
  } else {
    const dist = answers.weightKg < shoe.minWeightKg
      ? shoe.minWeightKg - answers.weightKg
      : answers.weightKg - shoe.maxWeightKg;
    score -= Math.min(dist * 0.4, 8);
  }

  // Width match
  if (shoe.widths.includes(answers.width)) {
    score += 5;
  } else if (answers.width !== "standard") {
    score -= 6; // they specifically needed wide/narrow and this shoe doesn't offer it
  }

  // Budget
  if (answers.budgetMax >= 500) {
    // "$500+" — no real ceiling
    score += 2;
  } else if (shoe.price <= answers.budgetMax) {
    score += 4;
  } else {
    score -= Math.min((shoe.price - answers.budgetMax) * 0.05, 10);
  }

  // Experience fit (mostly matters for racers/spikes)
  if (shoe.experience !== "any") {
    score += shoe.experience === experience ? 4 : -3;
  }

  return score;
}

/**
 * Returns the top N shoe matches (default 3) for the given answers.
 * answers shape:
 * {
 *   discipline: "road" | "track" | "trail" | "xc",
 *   spikeChoice: "spikes" | "trainers" | null,
 *   eventType: "sprint" | "middle" | "long" | "unsure" | null,
 *   age: number,
 *   weightKg: number,
 *   weeklyDistanceKm: number,
 *   pronation: "overpronation" | "supination" | "neutral" | "unsure" | "noshoes",
 *   cushioningPref: "max" | "balanced" | "firm" | "minimal",
 *   budgetMax: number, // 500 means "$500+"
 *   width: "narrow" | "standard" | "wide" | "extra-wide"
 * }
 */
function getMatches(answers, count = 3) {
  const categories = getCandidateCategories(answers);
  const pool = SHOES.filter((s) => categories.includes(s.category));

  const scored = pool
    .map((shoe) => ({ shoe, score: scoreShoe(shoe, answers) }))
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, count).map((entry) => entry.shoe);
}
