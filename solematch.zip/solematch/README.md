# SoleMatch

A quiz that matches runners to the right shoe — road, track, trail, or cross country — based on discipline, spikes vs. trainers, age, weight, weekly distance, pronation, cushioning feel, budget, and width.

No build step, no framework, no dependencies. Plain HTML/CSS/JS.

## Project structure

```
solematch/
├── index.html          # page shell
├── css/
│   └── style.css       # all styling, design tokens, custom sliders
├── js/
│   ├── shoes.js         # the shoe dataset — add/edit shoes here
│   ├── matchLogic.js     # scoring engine that ranks shoes against answers
│   └── app.js            # quiz flow, state, and rendering
└── images/                # placeholder shoe images (swap for real photos)
```

## Run it locally

No install needed — just open `index.html` in a browser, or serve it locally:

```bash
cd solematch
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to GitHub Pages

1. Create a new repo and push this folder's contents to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/solematch.git
   git push -u origin main
   ```
2. On GitHub: go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to "Deploy from a branch", branch `main`, folder `/ (root)`.
4. Save. Your site will be live at `https://<your-username>.github.io/solematch/` within a minute or two.

## Swapping in real shoe images

Each shoe in `js/shoes.js` has an `image` field pointing at a file in `images/`. The included images are simple placeholder graphics — drop in real product photos with the same filenames (or update the `image` paths) to replace them.

## Adding more shoes

Add a new object to the `SHOES` array in `js/shoes.js` following the existing shape (`category`, `cushioning`, `responsiveness`, `widths`, `pronationSupport`, weight range, `experience`, `price`, `blurb`, `image`). No other file needs to change — the scoring engine in `matchLogic.js` picks it up automatically.
